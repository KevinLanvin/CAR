package tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.CharBuffer;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

import server.FTPRequestHandler;

public class FTPRequestHandlerTest extends TestCase {
	FTPRequestHandler requestHandler;
	SocketMock socket;
	ServerMock serverMock;

	@Before
	public void setUp() throws Exception {
		super.setUp();
		socket = new SocketMock();
		serverMock = new ServerMock();
		requestHandler = new FTPRequestHandler(socket, serverMock);
	}

	@Test
	public void testProcessQuit() {
		requestHandler.processQuit();
		assertEquals(requestHandler.state, ServerMock.ST_QUIT);
		assertTrue(socket.closed);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_QUIT));
	}

	/* Tests if a USER request is ignored in case of non-sense state */
	@Test
	public void testProcessUser1() {
		requestHandler.state = ServerMock.ST_QUIT;
		requestHandler.processUser("Tartempion");
		assertEquals(requestHandler.state, ServerMock.ST_BAD_REQUEST);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_BAD_REQUEST));
	}

	/* Tests if the right error message is sent when a bad username is typed */
	@Test
	public void testProcessUser2() {
		requestHandler.state = ServerMock.ST_READY;
		requestHandler.processUser("Tartempion");
		assertEquals(requestHandler.state, ServerMock.ST_AUTH_FAIL);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_AUTH_FAIL));
	}

	/*
	 * Tests if the connection process is going on correctly when a correct
	 * username is typed
	 */
	@Test
	public void testProcessUser3() {
		requestHandler.state = ServerMock.ST_READY;
		requestHandler.processUser("guest");
		assertTrue(requestHandler.state == ServerMock.ST_MDP);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_MDP));
	}

	@Test
	public void testProcessPassword1() {
		requestHandler.state = ServerMock.ST_READY;
		requestHandler.processPass("Tartempion");
		assertEquals(requestHandler.state, ServerMock.ST_BAD_REQUEST);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_BAD_REQUEST));
	}

	@Test
	public void testProcessPassword2() {
		requestHandler.state = ServerMock.ST_MDP;
		requestHandler.client = "guest";
		requestHandler.processPass("Tartempion");
		assertEquals(requestHandler.state, ServerMock.ST_AUTH_FAIL);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_AUTH_FAIL));
	}

	@Test
	public void testProcessPassword3() {
		requestHandler.state = ServerMock.ST_MDP;
		requestHandler.client = "tartempion";
		requestHandler.processPass("guest");
		assertEquals(requestHandler.state, ServerMock.ST_AUTH_FAIL);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_AUTH_FAIL));
	}

	@Test
	public void testProcessPassword4() {
		requestHandler.state = ServerMock.ST_MDP;
		requestHandler.client = "guest";
		requestHandler.processPass("guest");
		assertEquals(requestHandler.state, ServerMock.ST_AUTH_OK);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_AUTH_OK));
	}

	@Test
	public void testProcessPort1() {
		requestHandler.processPort("127,0,0,1,0,80");
		assertEquals(requestHandler.state, ServerMock.ST_CONNECTION_FAILED);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_CONNECTION_FAILED));
	}

	@Test
	public void testProcessPort2() throws IOException {
		ServerSocket ss = new ServerSocket(7655);
		requestHandler.processPort("127,0,0,1,29,231");
		assertEquals(requestHandler.state, ServerMock.ST_PORT_ACCEPTED);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_PORT_ACCEPTED));
		ss.close();
	}

	@Test
	public void testProcessSyst() {
		requestHandler.processSyst();
		assertEquals(requestHandler.state, ServerMock.ST_SYST);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_SYST));
	}

	@Test
	public void testProcessList() throws IOException {
		ServerSocket ss = new ServerSocket(7656);
		requestHandler.processPort("127,0,0,1,29,232");
		assertEquals(requestHandler.state, ServerMock.ST_PORT_ACCEPTED);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_PORT_ACCEPTED));
		Socket s = ss.accept();
		requestHandler.processList();
		assertEquals(requestHandler.state, ServerMock.ST_TRANSFERT_END);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_TRANSFERT_END));
		byte [] buffer = new byte[25];
		s.getInputStream().read(buffer);
		assertTrue(new String(buffer).contains("test.txt"));
		s.close();
		ss.close();
	}
	
	@Test
	public void testProcessStor() throws IOException{
		ServerSocket ss = new ServerSocket(7657);
		requestHandler.processPort("127,0,0,1,29,233");
		assertEquals(requestHandler.state, ServerMock.ST_PORT_ACCEPTED);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_PORT_ACCEPTED));
		Socket s = ss.accept();
		File testFile = new File("testFile");
		s.getOutputStream().write("test".getBytes());
		s.getOutputStream().close();
		requestHandler.processStor("testFile");
		s.close();
		ss.close();
		assertEquals(requestHandler.state, ServerMock.ST_TRANSFERT_END);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_TRANSFERT_END));
		File testFile2 = new File("./users/files/testFile");
		assertTrue(testFile2.exists());
		FileReader fr = new FileReader(testFile2);
		char [] buffer = new char [25];
		fr.read(buffer);
		assertTrue(new String(buffer).contains("test"));
		fr.close();
		testFile.delete();
		testFile2.delete();
	}
	
	@Test
	public void testProcessRetr() throws IOException{
		ServerSocket ss = new ServerSocket(7657);
		requestHandler.processPort("127,0,0,1,29,233");
		assertEquals(requestHandler.state, ServerMock.ST_PORT_ACCEPTED);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_PORT_ACCEPTED));
		Socket s = ss.accept();
		requestHandler.processRetr("test.txt");
		assertEquals(requestHandler.state, ServerMock.ST_TRANSFERT_END);
		assertTrue(socket.getOutputStream().toString()
				.contains("" + ServerMock.ST_TRANSFERT_END));
		byte [] buffer = new byte [255];
		s.getInputStream().read(buffer);
		assertTrue(new String(buffer).contains("bla"));
		s.close();
		ss.close();
	}
	
}
