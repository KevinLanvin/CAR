package tests;

import java.io.IOException;

import server.Server;

public class ServerMock extends Server {

	public ServerMock() throws IOException{
		serverSocket.close();
	}
}
