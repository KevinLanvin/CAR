package tests;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class SocketMock extends Socket {
	
	public boolean closed;
	public OutputStream output;
	public InputStream input;
	byte[] buffer;
	
	public SocketMock(){
		this.closed = false;
		buffer = new byte[25];
		output = new ByteArrayOutputStream();
		input = new ByteArrayInputStream(buffer);
	}
	
	public void close(){
		this.closed= true;
	}
	
	public OutputStream getOutputStream(){
		return output;
	}
	
	public InputStream getInputStream(){
		return input;
	}
	
	public InetAddress getInetAddress(){
			return InetAddress.getLoopbackAddress();
	}
}
